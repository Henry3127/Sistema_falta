<?php
// Configuração do Banco de Dados
$servername = "localhost";
$database = "sistema_falta";
$username = "root";
$password = "&tec77@info!";

// Criando a conexão
$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Erro na conexão: " . mysqli_connect_error());
}
echo "Conectado com sucesso!<br>";

// Atualizar aulas_tidas para TODOS os alunos
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['atualizar_todas_aulas'])) {
    $sql = "UPDATE tbl_faltas SET 
                aulas_tidas = aulas_tidas + 1, 
                freq_total = ((aulas_tidas + 1 - falta) / (aulas_tidas + 1)) * 100";

    if (mysqli_query($conn, $sql)) {
        echo "Aulas atualizadas e frequência recalculada para todos os alunos!<br>";
    } else {
        echo "Erro ao atualizar: " . mysqli_error($conn);
    }
}

// Adiciona falta individualmente
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['atualizar_individual']) && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // Buscar dados do aluno
    $sqlSelectFalta = "SELECT falta, aulas_tidas FROM tbl_faltas WHERE id = $id";
    $resultFalta = mysqli_query($conn, $sqlSelectFalta);

    if ($rowFalta = mysqli_fetch_assoc($resultFalta)) {
        $faltaAtual = intval($rowFalta['falta']);
        $aulasTidas = intval($rowFalta['aulas_tidas']) + 1;

        $novaFalta = $faltaAtual + 1;

        // Corrigindo o cálculo da frequência
        $porcentagemPresenca = (($aulasTidas - $novaFalta) / $aulasTidas) * 100;

        $sqlUpdate = "UPDATE tbl_faltas SET falta = $novaFalta, aulas_tidas = $aulasTidas, freq_total = $porcentagemPresenca WHERE id = $id";

        if (mysqli_query($conn, $sqlUpdate)) {
            echo "Falta adicionada e frequência atualizada com sucesso!<br>";
        } else {
            echo "Erro ao atualizar: " . mysqli_error($conn);
        }
    } else {
        echo "Aluno não encontrado.<br>";
    }
}

// Adicionar aula individual
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['atualizar_individual_aula']) && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // Buscar dados do aluno
    $sqlSelectAula = "SELECT aulas_tidas, falta FROM tbl_faltas WHERE id = $id";
    $resultAula = mysqli_query($conn, $sqlSelectAula);

    if ($rowAula = mysqli_fetch_assoc($resultAula)) {
        $aulaAtual = intval($rowAula['aulas_tidas']) + 1;
        $faltaAtual = intval($rowAula['falta']);

        // Corrigindo o cálculo da frequência
        $porcentagemPresenca = (($aulaAtual - $faltaAtual) / $aulaAtual) * 100;

        $sqlUpdate = "UPDATE tbl_faltas SET aulas_tidas = $aulaAtual, freq_total = $porcentagemPresenca WHERE id = $id";

        if (mysqli_query($conn, $sqlUpdate)) {
            echo "Aula adicionada e frequência atualizada com sucesso!<br>";
        } else {
            echo "Erro ao atualizar: " . mysqli_error($conn);
        }
    } else {
        echo "Aluno não encontrado.<br>";
    }
}

// Consultar alunos e faltas
$sqlSelect = "SELECT a.id, a.nome, a.serie, f.falta, f.aulas_tidas, f.freq_total 
              FROM tbl_aluno a 
              LEFT JOIN tbl_faltas f ON a.id = f.id";
$result = mysqli_query($conn, $sqlSelect);
?>




<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Faltas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="principalpolido_1.4.css" media="screen"/>
</head>
<body>
    

<header>
    <form method="POST">
    <img src="logo.png" alt="Logo" class="logo">
        <button class="button" type="submit" name="atualizar_todas_aulas">Atualizar Aulas para Todos</button>
    </form>
</header>
<hr>
<div class="T">
<h3>Lista de Alunos:</h3>
<?php
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
?>
        <div>
            <strong>ID:</strong> <?= $row["id"] ?> | 
            <strong>Nome:</strong> <?= $row["nome"] ?> | 
            <strong>Série:</strong> <?= $row["serie"] ?><br>
            <strong>Faltas:</strong> <?= $row['falta'] ?><br>
            <strong>Aulas Tidas:</strong> <?= $row['aulas_tidas'] ?><br>
            <strong>Frequência Total:</strong> <?= number_format($row['freq_total'], 2) ?>%<br>

            <form method="POST">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <button class="button2" type="submit" name="atualizar_individual">Faltou</button>
            </form>

            <form method="POST">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <button class="button2" type="submit" name="atualizar_individual_aula">aula</button>
            </form>

        </div>
        <hr>
<?php
    }
} else {
    echo "<p>Nenhum aluno encontrado.</p>";
}

mysqli_close($conn);
?>
</div>

<footer>
<div class="R">
    <h5>Registro Escolar Digital 2025</h5>
    </div>
</footer>

</body>
</html>
